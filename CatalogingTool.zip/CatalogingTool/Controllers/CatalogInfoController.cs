﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using ClosedXML.Excel;
using PagedList;

namespace Cognizant.FSE.CatalogingTool
{
    public class CatalogInfoController : Controller
    {
        TestEntities db = new TestEntities();       
        
        // GET: Catalog
        public ActionResult Index(string sortOrder, string BasicSearchString,string AdvancedSearchString,
           string CurrentBasicFilter, string CurrentAdvancedFilter, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";

            if (BasicSearchString != null || AdvancedSearchString != null)
            {
                page = 1;
            }
            else
            {
                BasicSearchString = CurrentBasicFilter;
                AdvancedSearchString = CurrentAdvancedFilter;
            }

            ViewBag.CurrentBasicFilter = BasicSearchString;
            ViewBag.CurrentAdvancedFilter = AdvancedSearchString;

            var catalogInfo = from s in db.Courses
                           select s;

            if (!String.IsNullOrEmpty(BasicSearchString))
            {
                catalogInfo = catalogInfo.Where(s => s.SkillName.Contains(BasicSearchString)
                                       || s.CourseTitle.Contains(BasicSearchString));
            }

            if (!String.IsNullOrEmpty(AdvancedSearchString))
            {
                catalogInfo = catalogInfo.Where(s => s.CourseCode.Contains(AdvancedSearchString)
                                       || s.CourseDescription.Contains(AdvancedSearchString)
                                       || s.LicenseDetails.Contains(AdvancedSearchString)
                                       || s.ActivityType.Contains(AdvancedSearchString));
            }

            switch (sortOrder)
            {              
                case "Date":
                    catalogInfo = catalogInfo.OrderBy(s => s.CreateDateTime);
                    break;
                case "date_desc":
                    catalogInfo = catalogInfo.OrderByDescending(s => s.CreateDateTime);
                    break;
                default:
                    catalogInfo = catalogInfo.OrderBy(s => s.CourseID);
                    break;
            }
            //Save in session to export to excel
            Session["filteredCatalog"] = catalogInfo.ToList(); ;
            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(catalogInfo.ToPagedList(pageNumber, pageSize));
        }

        [HttpPost]
        public FileResult ExportToExcel()
        {
            DataTable dt = new DataTable("CourseInfo");
            dt.Columns.AddRange(new DataColumn[10] { new DataColumn("CourseID"),
                                                     new DataColumn("CourseTitle"),
                                                     new DataColumn("CourseCode"),
                                                     new DataColumn("CourseDescription"),
                                                     new DataColumn("SkillName"),
                                                     new DataColumn("ProficiencyLevel"),
                                                     new DataColumn("LicenseDetails"),
                                                     new DataColumn("ActivityType"),
                                                     new DataColumn("CreateDateTime"),
                                                     new DataColumn("IsActive")});
            
            var courseInfo = (List<Course>)Session["filteredCatalog"];

            foreach (var course in courseInfo)
            {
                dt.Rows.Add(course.CourseID,course.CourseTitle,course.CourseCode,course.CourseDescription,course.SkillName,course.ProficiencyLevel, course.LicenseDetails,course.ActivityType,course.CreateDateTime,course.IsActive);
            }

            //ClosedXml from Nuget for XLWorkbook 
            using (XLWorkbook wb = new XLWorkbook())  
            {
                IXLWorksheet xLWorksheet = wb.Worksheets.Add(dt);
                xLWorksheet.Columns().AdjustToContents();
                xLWorksheet.Cells().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                using (MemoryStream stream = new MemoryStream()) 
                {                    
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "ExcelFile.xlsx");
                }
            }
        }

        [HttpPost]
        public ActionResult ImportFromExcel(HttpPostedFileBase postedFile)
        {
            if (ModelState.IsValid)
            {
                if (postedFile != null && postedFile.ContentLength > (1024 * 1024 * 50))  // 50MB limit  
                {
                    ModelState.AddModelError("postedFile", "Your file is to large. Maximum size allowed is 50MB !");
                }

                else
                {
                    string filePath = string.Empty;
                    string path = Server.MapPath("~/Uploads/");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    filePath = path + Path.GetFileName(postedFile.FileName);
                    string extension = Path.GetExtension(postedFile.FileName);
                    postedFile.SaveAs(filePath);

                    string conString = string.Empty;
                    switch (extension)
                    {
                        case ".xls": //For Excel 97-03.  
                            conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                            break;
                        case ".xlsx": //For Excel 07 and above.  
                            conString = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                            break;
                    }
                    try
                    {
                        DataTable dt = new DataTable();
                        conString = string.Format(conString, filePath);

                        using (OleDbConnection connExcel = new OleDbConnection(conString))
                        {
                            using (OleDbCommand cmdExcel = new OleDbCommand())
                            {
                                using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                                {
                                    cmdExcel.Connection = connExcel;

                                    //Get the name of First Sheet.  
                                    connExcel.Open();
                                    DataTable dtExcelSchema;
                                    dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                                    string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                                    connExcel.Close();

                                    //Read Data from First Sheet.  
                                    connExcel.Open();
                                    cmdExcel.CommandText = "SELECT * From [" + sheetName + "]";
                                    odaExcel.SelectCommand = cmdExcel;
                                    odaExcel.Fill(dt);
                                    connExcel.Close();
                                }
                            }
                        }

                        conString = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
                        using (SqlConnection con = new SqlConnection(conString))
                        {
                            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                            {
                                //Set the database table name.  
                                sqlBulkCopy.DestinationTableName = "Course";
                                con.Open();
                                sqlBulkCopy.WriteToServer(dt);
                                con.Close();
                                return Json("New Catalog Items added successfully");
                            }
                        }
                    }

                    //catch (Exception ex)  
                    //{  
                    //    throw ex;  
                    //}  
                    catch (Exception e)
                    {
                        return Json("error" + e.Message);
                    }
                    //return RedirectToAction("Index");  
                }
            }
            //return View(postedFile);  
            return Json("no files were selected !");
        }
    }
}